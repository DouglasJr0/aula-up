import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { ProdutoMercado } from '../models/ProdutoMercado';
import { Booking } from '../models/Booking';
import { BookDTO } from '../dtos/BookDTO';
import { ProdutoMercadoDTO } from '../dtos/ProdutoMercadoDTO';

@Injectable()
export class AppService {
  constructor(
    @InjectModel(ProdutoMercado)
    private produtoMercado: typeof ProdutoMercado,

    @InjectModel(Booking)
    private booking: typeof Booking,
  ) {}

  async putBooking(id: number, putData: BookDTO) {
    const booking = await this.booking.findOne({ where: { id } });
    if (!booking) throw new HttpException('Not Found booking to this id', HttpStatus.NOT_FOUND);
    return await booking.update(putData);
  }

  async putBookingByAuthorEmail(email: string, putData: BookDTO) {
    const booking = await this.booking.findOne({ where: { authorEmail: email } });
    if (!booking) throw new HttpException('Not Found booking to this authorEmail', HttpStatus.NOT_FOUND);
    return await booking.update(putData);
  }

  async deleteBooking(id: number) {
    const booking = await this.booking.findOne({ where: { id } });
    if (!booking) throw new HttpException('Not Found booking to this id', HttpStatus.NOT_FOUND);
    return await booking.destroy();
  }

  async deleteBookingByTitle(title: string) {
    const booking = await this.booking.findOne({ where: { title } });
    if (!booking) throw new HttpException('Not Found booking to this title', HttpStatus.NOT_FOUND);
    return await booking.destroy();
  }

  async putProdutoById(id: number, body: ProdutoMercadoDTO) {
    const produto = await this.produtoMercado.findOne({ where: { id } });
    if (!produto) throw new HttpException('Produto not found by ID', HttpStatus.NOT_FOUND);
    return await produto.update(body);
  }

  async putProdutoByNome(nome: string, body: ProdutoMercadoDTO) {
    const produto = await this.produtoMercado.findOne({ where: { nome } });
    if (!produto) throw new HttpException('Produto not found by Nome', HttpStatus.NOT_FOUND);
    return await produto.update(body);
  }

  async deleteProdutoByNome(nome: string) {
    const produto = await this.produtoMercado.findOne({ where: { nome } });
    if (!produto) throw new HttpException('Produto not found by Nome', HttpStatus.NOT_FOUND);
    return await produto.destroy();
  }
}
