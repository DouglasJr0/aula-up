import { Controller, Post, Body, Get, Param, Query, Put, Delete, HttpException, HttpStatus } from '@nestjs/common';
import { ProdutoMercadoDTO } from '../dtos/ProdutoMercadoDTO';
import { BookDTO } from '../dtos/BookDTO';
import { AppService } from '../services/AppService';
import { ProdutoMercado } from '../models/ProdutoMercado';
import { Booking } from '../models/Booking';
import { ResponseUpdateBooking } from '../responses/ResponseUpdateBooking';
import { ResponseDeleteDTO } from '../responses/ResponseDeleteDTO';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Post('/produto-mercado')
  createProdutoMercado(@Body() body: ProdutoMercadoDTO): ProdutoMercadoDTO {
    ProdutoMercado.create(body);
    return body;
  }

  @Post('/insert-object')
  insertObject(@Body() postData: { title: string; content?: string; authorEmail: string }) {
    return { result: postData };
  }

  @Get('/booking')
  async getBooking(): Promise<Booking[]> {
    return Booking.findAll();
  }

  @Get('/booking/:id')
  async getBookingById(@Param('id') id: number): Promise<Booking[]> {
    return Booking.findAll({ where: { id } });
  }

  @Get('/booking-querystring')
  async getBookingByQueryString(@Query('id') id: number): Promise<Booking[]> {
    return Booking.findAll({ where: { id } });
  }

  private validationIdElement(id: any) {
    if (!id) throw new HttpException('Server Error - id Request not found', HttpStatus.BAD_REQUEST);
  }

  private validationBody(body: any) {
    if (!Object.keys(body).length) throw new HttpException('Server Error - Body Request not found', HttpStatus.BAD_REQUEST);
  }

  private validation(id: any, body: any) {
    this.validationIdElement(id);
    this.validationBody(body);
  }

  @Put('/booking')
  async putBooking(@Query('id') id: number, @Body() body: BookDTO): Promise<ResponseUpdateBooking> {
    this.validation(id, body);
    return new ResponseUpdateBooking(await this.appService.putBooking(id, body));
  }

  @Put('/booking-author')
  async putBookingByEmail(@Query('email') email: string, @Body() body: BookDTO): Promise<ResponseUpdateBooking> {
    this.validationBody(body);
    return new ResponseUpdateBooking(await this.appService.putBookingByAuthorEmail(email, body));
  }

  @Put('/produto-mercado/id')
  async putProdutoById(@Query('id') id: number, @Body() body: ProdutoMercadoDTO) {
    this.validation(id, body);
    return await this.appService.putProdutoById(id, body);
  }

  @Put('/produto-mercado/nome')
  async putProdutoByNome(@Query('nome') nome: string, @Body() body: ProdutoMercadoDTO) {
    this.validationBody(body);
    return await this.appService.putProdutoByNome(nome, body);
  }

  @Delete('/booking')
  async deleteBooking(@Query('id') id: number): Promise<ResponseDeleteDTO> {
    this.validationIdElement(id);
    await this.appService.deleteBooking(id);
    return new ResponseDeleteDTO();
  }

  @Delete('/booking-title')
  async deleteBookingByTitle(@Query('title') title: string): Promise<ResponseDeleteDTO> {
    if (!title) throw new HttpException('Title not found', HttpStatus.BAD_REQUEST);
    await this.appService.deleteBookingByTitle(title);
    return new ResponseDeleteDTO();
  }

  @Delete('/produto-mercado')
  async deleteProdutoByNome(@Query('nome') nome: string): Promise<ResponseDeleteDTO> {
    if (!nome) throw new HttpException('Nome not found', HttpStatus.BAD_REQUEST);
    await this.appService.deleteProdutoByNome(nome);
    return new ResponseDeleteDTO();
  }
}
