export class ResponseDeleteDTO {
  public message: string;

  constructor() {
    this.message = 'Delete realizado com sucesso';
  }
}
